import React from "react";

export default class Article extends React.Component {
  render() {
    let style = {
      width: 700,
      height: 300
    };
    // replace hrefs w/ Link
    let href = this.props.title + ".html";
    return (
      <article class="col-md-4 article-intro">
        <a href={href}>
          <img
            class="img-responsive img-rounded"
            src="images/9-11.jpg"
            alt="700x300"
            style={style}
            data-holder-rendered="true"
          />
        </a>
        <h3>
          <a href={href}>{this.props.title}</a>
        </h3>
        <p>{this.props.caption}</p>
      </article>
    );
  }
}
