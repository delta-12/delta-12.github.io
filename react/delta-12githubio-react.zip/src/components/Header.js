import React from "react";
import Navbar from "./navbar/Navbar";

export default class Header extends React.Component {
  render() {
    return (
      <div class="jumbotron feature">
        <Navbar />
        <div class="container">
          <center>
            <h1>[ {this.props.header} ]</h1>
          </center>
        </div>
      </div>
    );
  }
}
