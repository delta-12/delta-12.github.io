import React from "react";

export default class Navbar extends React.Component {
  render() {
    return (
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
          <div class="navbar-header">
            <button
              type="button"
              class="navbar-toggle"
              data-toggle="collapse"
              data-target="#navbar"
            >
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbar">
              <ul class="nav navbar-nav">
                <li class="active">
                  <a href="/testing/index.html">Home</a>
                </li>
                <li>
                  <a href="/testing/about.html">About</a>
                </li>
                <li>
                  <a href="/testing/files/index.html">Files</a>
                </li>
                <li class="dropdown">
                  <a
                    href="#"
                    class="dropdown-toggle"
                    data-toggle="dropdown"
                    role="button"
                    aria-haspopup="true"
                    aria-expanded="false"
                  >
                    Hax <span class="caret"></span>
                  </a>
                  <ul class="dropdown-menu" aria-labelledby="about-us">
                    <li>
                      <a href="/testing/merlin_c2.html">Merlin C2</a>
                    </li>
                    <li>
                      <a href="/testing/vbscript.html">VBScript Fun</a>
                    </li>
                    <li>
                      <a href="/testing/batch.html">Batch Scripts</a>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
    );
  }
}
