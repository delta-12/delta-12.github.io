import React from "react";
import Header from "./components/Header";
import Article from "./components/Article";
import "./styles.css";
import "./custom.css";

export default function App() {
  return (
    <div className="App">
      <Header header="PWNED" />
      <div class="row">
        <article class="col-md-4 article-intro">
          <Article title="Test title" caption="Test Caption" />
        </article>
      </div>
    </div>
  );
}
